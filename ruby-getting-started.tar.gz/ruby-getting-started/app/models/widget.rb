class Widget < ActiveRecord::Base
end
